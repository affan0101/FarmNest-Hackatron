const hamburger = document.getElementById('hamburger');
const navLinks = document.getElementById('nav-links');
const searchContainer = document.getElementById('search-container');

hamburger.addEventListener('click', () => {
    navLinks.classList.toggle('active');
});
 // hero section 
 let slideIndex = 1;
showSlides(slideIndex);

// Next/previous controls
function plusSlides(n) {
    showSlides(slideIndex += n);
}

// Thumbnail image controls
function currentSlide(n) {
    showSlides(slideIndex = n);
}

function showSlides(n) {
    let i;
    let slides = document.getElementsByClassName("slider-image");
    let dots = document.getElementsByClassName("dot");

    if (n > slides.length) { slideIndex = 1 }
    if (n < 1) { slideIndex = slides.length }

    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
    }

    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
    }

    slides[slideIndex - 1].style.display = "block";
    dots[slideIndex - 1].className += " active";
}

// Auto slide functionality (optional)
setInterval(function() {
    plusSlides(1);
}, 5000); // Change image every 5 seconds





// login script 


document.getElementById("loginForm").addEventListener("submit", function(e) {
    e.preventDefault();
  
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;
  
    if (username === "" || password === "") {
      alert("Please fill out both fields.");
    } else {
      alert(`Welcome, ${username}!`);
      // Add authentication logic here
    }
  });



  //  register script  


  document.getElementById("registerForm").addEventListener("submit", function(e) {
    e.preventDefault();
  
    const firstName = document.getElementById("firstName").value;
    const lastName = document.getElementById("lastName").value;
    const email = document.getElementById("email").value;
    const mobile = document.getElementById("mobile").value;
  
    if (firstName === "" || lastName === "" || email === "" || mobile === "") {
      alert("Please fill out all fields.");
    } else if (mobile.length !== 10) {
      alert("Please enter a valid 10-digit mobile number.");
    } else {
      alert(`Thank you for registering, ${firstName} ${lastName}!`);
      // Add backend logic here for registration
    }
  });
  